#include <iostream>

#include "iDictionary.h"
#include "hashFunctions.h"
#include "hashTable.h"

int main(){

    HashTable<int, int> t(&HashInt, 10);
    t.Add(1990, 5);
    t.Add(2001, 7);
    std::cout << t.ContainsKey(1990) << " " << t.ContainsKey(1985) << "\n"; // 1 0
    std::cout << t.Get(2001) << " " << t.GetCount() << "\n";                // 7 2
    t.Remove(1990);
    std::cout << t.ContainsKey(1990) << " " << t.GetCount() << "\n";  // 0 1
    std::cout << t.Get(2001) << "\n";  

    std::cout << HashInt(1990) << " " << HashInt(1991) << "\n";
    std::cout << HashString("Ivanov") << " " << HashString("Petrov") << "\n";

    return 0;
}